self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a4de05b82f4c81bea5b2b6a8cf119022",
    "url": "46a948fe908034bf745c.worker.js"
  },
  {
    "revision": "4bb2b3a7bd09848f23b5",
    "url": "css/app.e99c7351.css"
  },
  {
    "revision": "c42fb57e35a3f8e281bc",
    "url": "css/chunk-vendors.8cf7dd44.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "4210c72299fba5d6d77eafb8d7c9d5be",
    "url": "index.html"
  },
  {
    "revision": "4bb2b3a7bd09848f23b5",
    "url": "js/app.c533a4b2.js"
  },
  {
    "revision": "c42fb57e35a3f8e281bc",
    "url": "js/chunk-vendors.c0f1029c.js"
  },
  {
    "revision": "28f3e13ec88073aa1b85b7d66358f613",
    "url": "manifest.json"
  },
  {
    "revision": "523b1a2eae8cb533fa6bd73831308f09",
    "url": "static/kgm.mask"
  }
]);